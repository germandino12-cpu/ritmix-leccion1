
import React from "react";
import ReactDOM from "react-dom/client";
import RitmiXLeccion1 from "./RitmiXLeccion1";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <RitmiXLeccion1 />
  </React.StrictMode>
);
